# GTAIV
请仔细阅读上面的 [GitHub使用方法及功能介绍.docx](./Github使用方法及功能介绍.docx) 以及下面的 [文本翻译须知.png](./文本翻译须知.png)
<br>
在领任务之前，请确保你已经在[工作表](https://docs.qq.com/sheet/DWmlST1dCcXp1TVJx?preview_token=&tdsourcetag=s_qq_aiomsg&tab=BB08J3&c=B3A0B0)上填上了你的名字，以免和别人的工作发生冲突
