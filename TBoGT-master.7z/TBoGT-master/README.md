# TBoGT
请仔细阅读上面的 [GitHub使用方法及功能介绍.docx](./Github使用方法及功能介绍.docx) 以及下面的 [文本翻译须知.png](./文本翻译须知.png)  
在领任务之前，请确保你已经在[工作表][table]上填上了你的名字，以免和别人的工作发生冲突 链接：[工作表][table]  

### 下面几个词有统一译名   
英|中
-|-
Gay Tony|基佬Tony
Maisonette 9|9号豪宅
Hercules|大力神

### 关于PR中的Label  
颜色|状态
-|-
红色|待审阅
黄色|已审阅 待修改
绿色|无问题 可merge

[table]:https://docs.qq.com/sheet/DWmlST1dCcXp1TVJx "填表"
